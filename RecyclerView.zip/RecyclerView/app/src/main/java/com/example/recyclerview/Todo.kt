package com.example.recyclerview

data class Todo (
    val title: String,
    var isChecked: Boolean
    )